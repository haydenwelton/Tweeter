export class Entity {}
